from brain_games.hello_message import hello_user


def run_game(game: "function"):
    name = hello_user()
    game(name)

